var constant = {
  baseURL: 'http://fluenser.atwebpages.com/public/',
  month: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug',   'Sep', 'Oct', 'Nev', 'Dec'],
};

export default constant;