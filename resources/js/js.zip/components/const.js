var constant = {
  baseURL: 'http://localhost:8000/',
  month: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug',   'Sep', 'Oct', 'Nev', 'Dec'],
};

export default constant;