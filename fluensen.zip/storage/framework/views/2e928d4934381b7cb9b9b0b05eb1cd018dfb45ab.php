
<?php $__env->startSection('content'); ?>


  <main class="md:max-w-7xl mx-auto">
    <div class="w-full">
      <!-- Replace with your content -->
        <div class="sm:px-0 bg-white">
          <div id="mail-component"></div>
        </div>
    </div>
  </main>
  <script src="<?php echo e(asset('js/app.js')); ?>" ></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\fluensen\fluensen\resources\views/message.blade.php ENDPATH**/ ?>