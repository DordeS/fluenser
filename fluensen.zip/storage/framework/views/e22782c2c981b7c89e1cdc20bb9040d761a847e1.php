

<?php $__env->startSection('content'); ?>
<header class="bg-white">
  <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
    <p class="text-center text-3xl" style="font-family: 'Josefin Sans', sans-serif;">Tasks</p>
  </div>
</header>
<main>
  <div class="max-w-md mx-auto sm:px-6 lg:px-8">
    <!-- Replace with your content -->
      <div class="px-4 sm:px-0 bg-white">
          <div class="mt-6">
            <div class="w-10/12 mx-auto">
              <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="w-full grid grid-rows-6">
                    <div class="w-full grid grid-cols-3" style="overflow: hidden;height:28px;">
                      <div class="col-span-1 font-bold">
                        TaskID
                      </div>
                      <div class="col-span-2">
                        <?php echo e($task->id); ?>

                      </div>
                    </div>
                    <div class="w-full grid grid-cols-3" style="overflow: hidden;height:28px;">
                      <div class="col-span-1 font-bold">
                        Brand
                      </div>
                      <div class="col-span-2">
                        <?php echo e($task->brand); ?>

                      </div>
                    </div>
                    <div class="w-full grid grid-cols-3" style="overflow: hidden;height:28px;">
                      <div class="col-span-1 font-bold">
                        Amount
                      </div>
                      <div class="col-span-2">
                        <?php echo e($task->amount); ?> <?php echo e($task->unit); ?>

                      </div>
                    </div>
                    <div class="w-full grid grid-cols-3" style="overflow: hidden;height:28px;">
                      <div class="col-span-1 font-bold">
                        Task
                      </div>
                      <div class="col-span-2">
                        <?php echo e($task->content); ?>

                      </div>
                    </div>
                    <div class="w-full grid grid-cols-3" style="overflow: hidden;height:28px;">
                      <div class="col-span-1 font-bold">
                        Status
                      </div>
                      <div class="col-span-2">
                        <?php switch($task->status):
                            case (1): ?>
                                Waiting for Deposit
                                <?php break; ?>
                            <?php case (2): ?>
                                Deposit Made
                                <?php break; ?>
                            <?php case (3): ?>
                                Deposit Released
                            <?php default: ?>
                                
                        <?php endswitch; ?>
                      </div>
                    </div>
                    <div class="w-full grid grid-cols-3" style="overflow: hidden;height:28px;">
                      <div class="col-span-1 font-bold">
                        Added Time
                      </div>
                      <div class="col-span-2">
                        <?php echo e($task->created_at); ?>

                      </div>
                    </div>
                    <hr class="mt-3 mb-8">
                  </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
      </div>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\fluensen\fluensen\resources\views/task.blade.php ENDPATH**/ ?>