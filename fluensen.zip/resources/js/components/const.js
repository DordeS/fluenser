var constant = {
  baseURL: 'http://fluee123.host/public/',
  month: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug',   'Sep', 'Oct', 'Nev', 'Dec'],
};

export default constant;