import axios from 'axios';

export default axios.create({
  baseURL: 'http://fluee123.host/public/api/'
});