<?php
namespace Ratchet;

interface MessageComponentInterface extends ComponentInterface, MessageInterface {
}
